let macas = [];
let contagem = 0;

function setup() {
  createCanvas(800, 600);
  // Criando maçãs de forma aleatória na tela
  for (let i = 0; i < 10; i++) {
    let x = random(300,400 ); // posição aleatória no eixo X
    let y = random(200, 80); // posição aleatória no eixo Y
    macas.push(createVector(x, y)); // armazenando posição das maçãs
  }
}

function draw() {
  background(135, 206, 235); // Céu azul
  
  // Desenhando a grama
  fill(34, 139, 34);
  noStroke();
  rect(0, height / 2, width, height / 2);
  
  // Desenhando a árvore
  drawArvore();

  // Desenhando as maçãs
  drawMacas();

  // Exibindo a contagem de maçãs colhidas
  fill(0);
  textSize(24);
  text("Maçãs Colhidas: " + contagem, 20, 40);
}

// Função para desenhar a árvore
function drawArvore() {
  // Desenhando o tronco da árvore
  fill(139, 69, 19);
  rect(350, height / 2 - 150, 30, 150); // tronco

  // Desenhando as folhas da árvore
  fill(34, 139, 34);
  ellipse(365, height / 2 - 180, 150, 150); // copa da árvore
}

// Função para desenhar as maçãs
function drawMacas() {
  for (let i = 0; i < macas.length; i++) {
    fill(255, 0, 0); // cor das maçãs
    ellipse(macas[i].x, macas[i].y, 30, 30); // desenha a maçã
  }
}

// Função que detecta o clique do mouse
function mousePressed() {
  // Verificando se o clique foi em alguma maçã
  for (let i = macas.length - 1; i >= 0; i--) {
    let d = dist(mouseX, mouseY, macas[i].x, macas[i].y);
    if (d < 15) { // Se o clique for dentro do círculo da maçã
      macas.splice(i, 1); // Remove a maçã
      contagem++; // Aumenta a contagem de maçãs colhidas
      break;
    }
  }
}
